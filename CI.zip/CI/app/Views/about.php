<div class="vg-page page-about" id="about">
    <div class="container py-5">
      <div class="row">
        <div class="col-lg-4 py-3">
          <div class="img-place wow fadeInUp">
            <img src="../assets/img/pf.png" alt="">
          </div>
        </div>
        <div class="col-lg-6 offset-lg-1 wow fadeInRight">
          <h1 class="fw-light">Fika Nuraeni</h1>
          <h5 class="fg-theme mb-3">Colleger</h5>
          <p class="text-muted">I am a student of Muhammadiyah Sukabumi University here I majored in Informatics Engineering. I am currently in my 4th semester.</p>
          <ul class="theme-list">
            <li><b>From:</b> Cianjur, Jawa Barat</li>
            <li><b>Lives In:</b> Sukabumi, Jawa Barat</li>
            <li><b>Age:</b> 21</li>
            <li><b>Gender:</b> females</li>
          </ul>
        </div>
      </div>
    </div>
    <div class="container py-5">
      <h1 class="text-center fw-normal wow fadeIn">My Skills</h1>
      <div class="row py-3">
        <div class="col-md-6">
          <div class="px-lg-3">
            <h4 class="wow fadeInUp">Coding skills</h4>
            <div class="progress-wrapper wow fadeInUp">
              <span class="caption">javascript</span>
              <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 40%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">40%</div>
              </div>
            </div>
            <div class="progress-wrapper wow fadeInUp">
              <span class="caption">PHP</span>
              <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 50%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">50%</div>
              </div>
            </div>
            <div class="progress-wrapper wow fadeInUp">
              <span class="caption">HTML + CSS</span>
              <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 50%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">50%</div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <div class="px-lg-3">
            <h4 class="wow fadeInUp">Design Skills</h4>
            <div class="progress-wrapper wow fadeInUp">
              <span class="caption">UI / UX Design</span>
              <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 40%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">40%</div>
              </div>
            </div>
            <div class="progress-wrapper wow fadeInUp">
              <span class="caption">Web Design</span>
              <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 55%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">55%</div>
              </div>
            </div>
            <div class="progress-wrapper wow fadeInUp">
              <span class="caption">Logo Design</span>
              <div class="progress">
                <div class="progress-bar" role="progressbar" style="width: 60%;" aria-valuenow="75" aria-valuemin="0" aria-valuemax="100">60%</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container pt-5">
      <div class="row">
        <div class="col-md-6 wow fadeInRight">
          <h2 class="fw-normal">Education</h2>
          <ul class="timeline mt-4 pr-md-5">
            
          <div class="row">
                  
 <?php foreach ($porto as $row): ?>
            <li>
              <div class="title"><?=$row['edu_in']?> <i>to</i> <?=$row['edu_out']?></div>
              <div class="details">
                <h5><?=$row['edu_name']?>se</h5>
                <small class="fg-theme"></small>
                <p><?=$row['edu_detail']?></p>
              </div>
            </li>
 <?php endforeach; ?>
          </ul>

        </div>
        



        
        <div class="col-md-6 wow fadeInRight" data-wow-delay="200ms">
          <h2 class="fw-normal">Experience</h2>
          <ul class="timeline mt-4 pr-md-5">
            <li>
              <div class="title"></div>
              <div class="details">
                <h5>Daily Governing Body of Intra-School Student Organization</h5>
                <small class="fg-theme">Senior High School</small>
                <p>Here I served as secretary for two years from 2018 to 2019</p>
              </div>
            </li>
            <li>
              <div class="title">2018</div>
              <div class="details">
                <h5>Chairman of Paskibra</h5>
                <small class="fg-theme">Senior High School</small>
                <p>In extracurricular I was mandated as the chairperson of the women's paskibra period 2019-2020</p>
              </div>
            </li>
            <li>
              <div class="title">2019</div>
              <div class="details">
                <h5>Training Affairs Division </h5>
                <small class="fg-theme">Cianjur Regency Paskibra Forum</small>
                <p>Here I participated in the management of the Paskibra Forum cianjuur regency as a member of the Training Affairs Division</p>
              </div>
            </li>
          </ul>
        </div>
      </div>
    </div>
    
  </div>
  <div class="vg-page page-service">
    <div class="container">
      <div class="text-center wow fadeInUp">
        <div class="badge badge-subhead">Service</div>
      </div>
      <h1 class="fw-normal text-center wow fadeInUp">What can i do?</h1>
      <div class="row mt-5">
        <div class="col-md-6 col-lg-4 col-xl-3">
          <div class="card card-service wow fadeInUp">
            <div class="icon">
              <span class="ti-paint-bucket"></span>
            </div>
            <div class="caption">
              <h4 class="fg-theme">Web Design</h4>  
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 col-xl-3">
          <div class="card card-service wow fadeInUp">
            <div class="icon">
              <span class="ti-search"></span>
            </div>
            <div class="caption">
              <h4 class="fg-theme">Logo</h4>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 col-xl-3">
          <div class="card card-service wow fadeInUp">
            <div class="icon">
              <span class="ti-vector"></span>
            </div>
            <div class="caption">
              <h4 class="fg-theme">UI/UX Design</h4>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 col-xl-3">
          <div class="card card-service wow fadeInUp">
            <div class="icon">
              <span class="ti-desktop"></span>
            </div>
            <div class="caption">
              <h4 class="fg-theme">Web Development</h4>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
