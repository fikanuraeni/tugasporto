<body class="theme-red">
<?= $this->include('button'); ?>
<?= $this->include('navbar'); ?>
<?= $this->include('about'); ?>
<?= $this->include('portfolio'); ?>
<?= $this->include('blog'); ?>
<?= $this->include('contact'); ?>
<?= $this->include('footer'); ?>
<script src="../assets/js/jquery-3.5.1.min.js"></script>
    
    <script src="../assets/js/bootstrap.bundle.min.js"></script>
      
    <script src="../assets/vendor/owl-carousel/owl.carousel.min.js"></script>
      
    <script src="../assets/vendor/perfect-scrollbar/js/perfect-scrollbar.js"></script>
      
    <script src="../assets/vendor/isotope/isotope.pkgd.min.js"></script>
      
    <script src="../assets/vendor/nice-select/js/jquery.nice-select.min.js"></script>
      
    <script src="../assets/vendor/fancybox/js/jquery.fancybox.min.js"></script>
  
    <script src="../assets/vendor/wow/wow.min.js"></script>
  
    <script src="../assets/vendor/animateNumber/jquery.animateNumber.min.js"></script>
  
    <script src="../assets/vendor/waypoints/jquery.waypoints.min.js"></script>
  
    <script src="../assets/js/google-maps.js"></script>
      
    <script src="../assets/js/topbar-virtual.js"></script>
  
    <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAIA_zqjFMsJM_sxP9-6Pde5vVCTyJmUHM&callback=initMap"></script>
    
  </body>
  </html>